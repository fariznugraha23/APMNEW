<?php $__env->startSection('title', 'Edit Data Apm'); ?>
	
<?php $__env->startSection('contents'); ?>
	<section class="breadcrumb">	
		<div class="container">
			<div class="row">
				<div class="col-sm-9">
					<h1>Edit Data Apm</h1>	
				</div>
			</div>
		</div>
	</section>

	<section class="contact-container">
	
		<div class="container">
			
			<div class="row">
				<div class="col-md-3"></div>
				
				<div class="col-md-6">
					<form class="contact-form" role="form" method="post" action="<?php echo e(route('home_editApmStore', ['id' => $apms->id_apm])); ?>" enctype="multipart/form-data">
						<?php echo e(csrf_field()); ?>

						
						<div class="form-group">
                            <label for="validationCustom01">Area</label>
							<input type="text" name="id_area" class="form-control" value="<?php echo e($apms->id_area); ?>" placeholder="Area:" />
						</div>
						
						<div class="form-group">
                            <label for="validationCustom01">Area RB</label>
							<input type="text" name="area_rb" class="form-control" value="<?php echo e($apms->area_rb); ?>" placeholder="Area RB:" />
						</div>

						<div class="form-group">
                        <label for="validationCustom01">Penilaian</label>
							<input type="text" name="penilaian" class="form-control" value="<?php echo e($apms->penilaian); ?>" placeholder="Penilaian:" />
						</div>
                        <div class="form-group">
                        <label for="validationCustom01">A</label>
							<input type="text" name="a" class="form-control" value="<?php echo e($apms->a); ?>" placeholder="A:" />
						</div>
                        <div class="form-group">
                        <label for="validationCustom01">B</label>
							<input type="text" name="b" class="form-control" value="<?php echo e($apms->b); ?>" placeholder="B:" />
						</div>
                        <div class="form-group">
                        <label for="validationCustom01">C</label>
							<input type="text" name="c" class="form-control" value="<?php echo e($apms->c); ?>" placeholder="C:" />
						</div>
                        <div class="form-group">
                        <label for="validationCustom01">Nilai</label>
							<input type="text" name="nilai" class="form-control" value="<?php echo e($apms->nilai); ?>" placeholder="Nilai:" />
						</div>
                        <div class="form-group">
                        <label for="validationCustom01">Kriteria</label>
							<input type="text" name="id_kriteria" class="form-control" value="<?php echo e($apms->id_kriteria); ?>" placeholder="Kriteria:" />
						</div>
                        <div class="form-group">
                        <label for="validationCustom01">Bobot</label>
							<input type="text" name="bobot" class="form-control" value="<?php echo e($apms->bobot); ?>" placeholder="Bobot:" />
						</div>
						<!-- <div class="form-group">
							<input type="file" name="image" class="form-control" />
						</div> -->
						
						<div class="form-group text-right">
							<button class="btn btn-primary" name="send">Save</button>
						</div>
						
					</form>
					
				</div>
				<div class="col-md-3"></div>
				
			</div>
			
		</div>
		
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>