<?php $__env->startSection('title', 'Detail'); ?>
	
<?php $__env->startSection('contents'); ?>
	<!-- Breadcrumb -->
	<section class="breadcrumb">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<h1>Detail Eviden</h1>
					<ol class="breadcrumb bc-3">
						<li>
							<a href="<?php echo e(route('home')); ?>"><i class="entypo-home"></i>Home</a>
						</li>
						<li class="active">
							<strong><?php echo e($apms->area_apm->nama_area); ?></strong>
						</li>
					</ol>			
				</div>
			</div>
		</div>
	</section>


	<!-- About Us Text -->
	<section class="content-section">
		<div class="container">
			
			<div class="row">
			<?php if(Auth::check()): ?>
			<!-- <div class="col-sm-2"></div>
			<div class="col-sm-8"> -->
			<h3><?php echo e($apms->area_apm->nama_area); ?></h3>
					<br />
					<table class="table">
						<tr>
							<td style="font-weight: bold;">Area RB</td>
							<td><?php echo e($apms->area_rb); ?></td>
						</tr>
						<tr>
							<td style="font-weight: bold;">Penilaian</td>
							<td><?php echo e($apms->penilaian); ?></td>
						</tr>
						<tr>
							<td style="font-weight: bold;">A</td>
							<td><?php echo e($apms->a); ?></td>
						</tr>
						<tr>
							<td style="font-weight: bold;">B</td>
							<td><?php echo e($apms->b); ?></td>
						</tr>
						<tr>
							<td style="font-weight: bold;">C</td>
							<td><?php echo e($apms->c); ?></td>
						</tr>
						<tr>
							<td style="font-weight: bold;">Nilai</td>
							<td><?php echo e($apms->nilai); ?></td>
						</tr>
						<tr>
							<td style="font-weight: bold;">Kriteria</td>
							<td><?php echo e($apms->kriteria_apm->nama_kriteria); ?></td>
						</tr>
						<tr>
							<td style="font-weight: bold;">Bobot</td>
							<td><?php echo e($apms->bobot); ?></td>
						</tr>
						<tr>
							<td style="font-weight: bold;">Skor</td>
							<td><?php echo e($apms->skor); ?></td>
						</tr>
					</table>
					
					<hr style="border: 3px solid black;border-radius: 5px;">
					<br>
					<!-- </div>
			<div class="col-sm-2"></div> -->
			<?php endif; ?>
			<?php if(!Auth::check()): ?>
				<div class="col-sm-6">
					<h3><?php echo e($apms->area_apm->nama_area); ?></h3>
					<br />
					<table class="table">
						<tr>
							<td style="font-weight: bold;">Area RB</td>
							<td><?php echo e($apms->area_rb); ?></td>
						</tr>
						<tr>
							<td style="font-weight: bold;">Penilaian</td>
							<td><?php echo e($apms->penilaian); ?></td>
						</tr>
						<tr>
							<td style="font-weight: bold;">A</td>
							<td><?php echo e($apms->a); ?></td>
						</tr>
						<tr>
							<td style="font-weight: bold;">B</td>
							<td><?php echo e($apms->b); ?></td>
						</tr>
						<tr>
							<td style="font-weight: bold;">C</td>
							<td><?php echo e($apms->c); ?></td>
						</tr>
						<tr>
							<td style="font-weight: bold;">Nilai</td>
							<td><?php echo e($apms->nilai); ?></td>
						</tr>
						<tr>
							<td style="font-weight: bold;">Kriteria</td>
							<td><?php echo e($apms->kriteria_apm->nama_kriteria); ?></td>
						</tr>
						<tr>
							<td style="font-weight: bold;">Bobot</td>
							<td><?php echo e($apms->bobot); ?></td>
						</tr>
						<tr>
							<td style="font-weight: bold;">Skor</td>
							<td><?php echo e($apms->skor); ?></td>
						</tr>
					</table>

				</div>
				<div class="col-sm-6">
					
					<table class="table">
						<thead>
							<tr>
								<th scope="col">Nomor</th>
								<th scope="col">Title</th>
								<th scope="col">Action</th>
							</tr>
						</thead>
						<tbody>
						<?php $no=1;?>
							<?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td ><?php echo $no; ?></th>
								<td><?php echo e($f->title); ?></td>
								<td><button type="button" class="btn btn-success">Download</button></td>	
							</tr>
							<?php $no++;?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>	
				</div>
				<?php endif; ?>
			</div>
			
			<?php if(Auth::check()): ?>
			<div class="row">
			<div class="col-sm-6">
					<form class="contact-form" role="form" method="POST" action="<?php echo e(route('home_uploadEviden')); ?>" enctype="multipart/form-data">
					<?php echo e(csrf_field()); ?>

						<div class="form-group">
							<label for="exampleInputText1">Title Eviden</label>
							<input type="hidden" class="form-control" name="id_apm" value="<?php echo e($apms->id_apm); ?>">
							<input type="text" class="form-control" id="exampleInputText1" name="title" placeholder="Title">
						</div>
						<div class="form-group">
							<label for="exampleFile1">File Eviden</label>
							<input type="file" class="form-control" name="pdf" id="exampleFile1" >
						</div>
						<button type="submit" class="btn btn-primary" name="submit">Submit</button>
					</form>
				</div>
				<div class="col-sm-6">
					<table class="table">
						<thead>
							<tr>
								<th scope="col">Nomor</th>
								<th scope="col">Title</th>
								<th scope="col">Action</th>
							</tr>
						</thead>
						<tbody>
						<?php $no=1;?>
							<?php $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td ><?php echo $no; ?></th>
								<td><?php echo e($f->title); ?></td>
								<td><button type="button" class="btn btn-success">Download</button></td>	
							</tr>
							<?php $no++;?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>
				</div>
				
			</div>
			<?php endif; ?>
		</div>	
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>