<div class="sidebar-menu">		
	<header class="logo-env">
		<!-- logo -->
		<div class="logo">
			<a href="index.html">
				<img src="<?php echo e(asset('assets')); ?>/admin/images/logo@2x.png" width="120" alt="" />
			</a>
		</div>
			
		<div class="sidebar-collapse">
			<a href="#" class="sidebar-collapse-icon with-animation"><!-- add class "with-animation" if you want sidebar to have animation during expanding/collapsing transition -->
				<i class="entypo-menu"></i>
			</a>
		</div>
		
		<div class="sidebar-mobile-menu visible-xs">
			<a href="#" class="with-animation"><!-- add class "with-animation" to support animation -->
				<i class="entypo-menu"></i>
			</a>
		</div>
	</header>
			
	<ul id="main-menu" class="">
		<li class="opened">
			<a href="index.html">
				<span>Menu</span>
			</a>
			<ul>
				<li <?php echo e(Request::is('admin') ? 'class=active' : ''); ?>>
					<a href="<?php echo e(route('dashboard')); ?>">
						<i class="entypo-gauge"></i>
						<span>Dashboard</span>
					</a>
				</li>
				<?php if(Auth::user()->id_role == 1): ?>
				<li <?php echo e(Request::is('admin/buku*') ? 'class=active' : ''); ?>>
					<a href="<?php echo e(route('buku')); ?>">
						<i class="entypo-book"></i>
						<span>List Buku</span>
					</a>
				</li>
				<?php endif; ?>
				<?php if(Auth::user()->id_role == 1): ?>
				<li <?php echo e(Request::is('admin/kategori*') ? 'class=active' : ''); ?>>
					<a href="<?php echo e(route('kategori')); ?>">
						<i class="entypo-book"></i>
						<span>List Kategori</span>
					</a>
				</li>
				<?php endif; ?>
				<li <?php echo e(Request::is('admin/transaksi*') ? 'class=active' : ''); ?>>
					<a href="<?php echo e(route('transaksi')); ?>">
						<i class="entypo-print"></i>
						<span>Transaksi</span>
					</a>
				</li>
				<?php if(Auth::user()->id_role == 1): ?>
				<li <?php echo e(Request::is('admin/member*') ? 'class=active' : ''); ?>>
					<a href="<?php echo e(route('member')); ?>">
						<i class="entypo-user"></i>
						<span>Member</span>
					</a>
				</li>
				<?php endif; ?>
			</ul>
		</li>
	</ul>		
</div>