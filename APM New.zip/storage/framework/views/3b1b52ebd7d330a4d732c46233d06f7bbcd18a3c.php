<!-- Bottom Scripts -->
<script src="<?php echo e(asset('assets')); ?>/front/js/gsap/main-gsap.js"></script>
<script src="<?php echo e(asset('assets')); ?>/front/js/bootstrap.js"></script>
<script src="<?php echo e(asset('assets')); ?>/front/js/joinable.js"></script>
<script src="<?php echo e(asset('assets')); ?>/front/js/resizeable.js"></script>
<script src="<?php echo e(asset('assets')); ?>/front/js/neon-slider.js"></script>
<script src="<?php echo e(asset('assets')); ?>/front/js/neon-custom.js"></script>