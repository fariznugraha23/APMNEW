<?php $__env->startSection('title', 'Setting Profile'); ?>
	
<?php $__env->startSection('contents'); ?>
	<section class="breadcrumb">	
		<div class="container">
			<div class="row">
				<div class="col-sm-9">
					<h1>Setting Profile</h1>	
				</div>
			</div>
		</div>
	</section>

	<section class="contact-container">
	
		<div class="container">
			
			<div class="row">
				<div class="col-md-3"></div>
				
				<div class="col-md-6">
					<form class="contact-form" role="form" method="post" action="<?php echo e(route('home_setting_store')); ?>" enctype="multipart/form-data">
						<?php echo e(csrf_field()); ?>

						
						<div class="form-group">
							<input type="text" name="name" class="form-control" value="<?php echo e($member->name); ?>" placeholder="Name:" />
						</div>
						
						<div class="form-group">
							<input type="text" name="email" class="form-control" value="<?php echo e($member->email); ?>" placeholder="E-mail:" />
						</div>

						<div class="form-group">
							<input type="text" name="password" class="form-control" placeholder="Password:" />
						</div>

						<div class="form-group">
							<input type="file" name="image" class="form-control" />
						</div>
						
						<div class="form-group text-right">
							<button class="btn btn-primary" name="send">Send</button>
						</div>
						
					</form>
					
				</div>
				<div class="col-md-3"></div>
				
			</div>
			
		</div>
		
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>