	<!-- Logo and Navigation -->
<div class="site-header-container container">

	<div class="row">
	
		<div class="col-md-12">
			
			<header class="site-header">
			
				<section class="site-logo">
				
					<a href="<?php echo e(route('home')); ?>">
						<img src="<?php echo e(asset('assets')); ?>/front/images/logo@2x.png" width="120" />
						<!-- <h1>Perpustakaan Normal</h1> -->
					</a>
					
				</section>
				
				<nav class="site-nav">
					
					<ul class="main-menu hidden-xs" id="main-menu">
						<li <?php echo e(Request::is('/') ? 'class=active' : ''); ?>>
							<a href="<?php echo e(route('home')); ?>">
								<span>Home</span>
							</a>
						</li>
						<!-- <li class="<?php echo e($_SERVER['REQUEST_URI'] == '/list' ? 'active' : ''); ?>">
							<a href="<?php echo e(route('home_daftarbuku')); ?>">
								<span>Area Apm</span>
							</a>
						</li> -->

						<?php if(!Auth::check()): ?>
							<li>
								<a href="<?php echo e(route('login')); ?>">
									<span>Login</span>
								</a>
							</li>
						<?php endif; ?>

						<?php if(Auth::check()): ?>
							<li>
								<a href="#">
									<span><?php echo e(Auth::user()->name); ?></span>
								</a>
								
								<ul>
									<?php if(Auth::user()->id_role == 3): ?>
										<li>
											<a href="<?php echo e(route('home_setting')); ?>">
												<span>Setting</span>
											</a>
										</li>
									<?php endif; ?>
									<li>
										<a href="<?php echo e(route('logout')); ?>"
							                onclick="event.preventDefault();
							                         document.getElementById('logout-form').submit();">
							                Log Out <i class="entypo-logout right"></i>
							            </a>

							            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
							                <?php echo e(csrf_field()); ?>

							            </form>
									</li>
								</ul>
							</li>
						<li class="search">
							<a href=""></a>
							<img src="<?php echo e(asset('uploaded/member')); ?>/<?php echo e(Auth::user()->image); ?>" width="50px" class="img-circle" />
						</li>
						<?php endif; ?>
					</ul>
					
				
					<div class="visible-xs">
						
						<a href="#" class="menu-trigger">
							<i class="entypo-menu"></i>
						</a>
						
					</div>
				</nav>
				
			</header>
			
		</div>
		
	</div>
	
</div>