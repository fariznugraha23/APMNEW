<?php $__env->startSection('title', 'Transaksi'); ?>
	
<?php $__env->startSection('contents'); ?>
	<section class="breadcrumb">	
		<div class="container">
			<div class="row">
				<div class="col-sm-9">
					<h1>Buku yang sedang dipinjam</h1>	
				</div>
			</div>
		</div>
	</section>


	<!-- Blog -->
	<section class="blog">
		<div class="container">
			<div class="row">
				<div class="col-sm-12">
					<div class="blog-posts">
						
						<!-- Blog Post -->	
						<?php $__empty_1 = true; $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>				
							<div class="blog-post">	
								<div class="post-thumb">
									<a href="#">
										<img src="<?php echo e(asset('uploaded/buku')); ?>/<?php echo e($t->buku->image); ?>" style="width: 300px; height: 350px" class="img-rounded" />
									</a>
								</div>
								
								<div class="post-details">
									<h3>
										<a href="#"><?php echo e($t->buku->judul); ?></a>
									</h3>
									<table class="table">
										<tr>
											<td>
												<div class="meta-info">
													<i class="entypo-comment"></i>
													Waktu Peminjaman
												</div>
											</td>
											<td>
												<div class="meta-info">
													<i class="entypo-calendar"></i> <?php echo e($t->tgl_pinjam); ?>								
												</div>
											</td>
										</tr>
										<tr>
											<td>
												<div class="meta-info">
													<i class="entypo-comment"></i>
													Kategori Buku
												</div>
											</td>
											<td>
												<div class="meta-info">
													<i class="entypo-book"></i> <?php echo e($t->buku->kategori->kategori); ?>								
												</div>
											</td>
										</tr>
										<tr>
											<td>
												<div class="meta-info">
													<i class="entypo-comment"></i>
													Pengarang
												</div>
											</td>
											<td>
												<div class="meta-info">
													<i class="entypo-user"></i> <?php echo e($t->buku->pengarang); ?>								
												</div>
											</td>
										</tr>
										<tr>
											<td>
												<div class="meta-info">
													<i class="entypo-comment"></i>
													Penerbit
												</div>
											</td>
											<td>
												<div class="meta-info">
													<i class="entypo-book"></i> <?php echo e($t->buku->penerbit); ?>								
												</div>
											</td>
										</tr>
										<tr>
											<td>
												<div class="meta-info">
													<i class="entypo-comment"></i>
													Tahun Terbit
												</div>
											</td>
											<td>
												<div class="meta-info">
													<i class="entypo-calendar"></i> <?php echo e($t->buku->tahun); ?>								
												</div>
											</td>
										</tr>
									</table>
									
									<form action="<?php echo e(route('home_pengembalian')); ?>" method="POST">
										<?php echo e(csrf_field()); ?>

										<input type="hidden" name="id" value="<?php echo e($t->id); ?>">
										<input type="hidden" name="id_buku" value="<?php echo e($t->id_buku); ?>">
										<button class="btn btn-danger">Kembalikan</button>
									</form>
								</div>
							</div>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
							<p>Belum ada buku yang dipinjam</p>
						<?php endif; ?>
					</div>
				</div>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>