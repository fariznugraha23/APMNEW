<!DOCTYPE html>
<html>
<head>
    <title>Cetak Transaksi</title>
</head>
<body>
	<h1>Data Transaksi Buku</h1>
	<div id="myDiv">
		<table class="table" border="1" cellspacing="0" cellpadding="2" width="100%">
			<thead class=".thead-dark">
				<tr>
					<th>No</th>
					<th>Nama Peminjam</th>
					<th>Judul Buku</th>
					<th>Tanggal Pinjam</th>
					<th>Tanggal Kembali</th>
				</tr>
			</thead>
			<tbody>
				<?php $no = 1; ?>
				<?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($no++); ?></td>
						<td><?php echo e($t->user->name); ?></td>
						<td><?php echo e($t->buku->judul); ?></td>
						<td><?php echo e($t->tgl_pinjam); ?></td>
						<td><?php echo e($t->tgl_kembali); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>

</body>

</html>