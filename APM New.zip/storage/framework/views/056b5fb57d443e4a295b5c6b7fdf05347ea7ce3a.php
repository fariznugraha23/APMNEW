<link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/admin/js/jvectormap/jquery-jvectormap-1.2.2.css">
<link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/admin/js/rickshaw/rickshaw.min.css">

<!-- Bottom Scripts -->
<script src="<?php echo e(asset('assets')); ?>/admin/js/gsap/main-gsap.js"></script>
<script src="<?php echo e(asset('assets')); ?>/admin/js/jquery-ui/js/jquery-ui-1.10.3.minimal.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/admin/js/bootstrap.js"></script>
<script src="<?php echo e(asset('assets')); ?>/admin/js/joinable.js"></script>
<script src="<?php echo e(asset('assets')); ?>/admin/js/resizeable.js"></script>
<script src="<?php echo e(asset('assets')); ?>/admin/js/neon-api.js"></script>
<script src="<?php echo e(asset('assets')); ?>/admin/js/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/admin/js/jvectormap/jquery-jvectormap-europe-merc-en.js"></script>
<script src="<?php echo e(asset('assets')); ?>/admin/js/jquery.sparkline.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/admin/js/rickshaw/vendor/d3.v3.js"></script>
<script src="<?php echo e(asset('assets')); ?>/admin/js/rickshaw/rickshaw.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/admin/js/raphael-min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/admin/js/morris.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/admin/js/toastr.js"></script>
<script src="<?php echo e(asset('assets')); ?>/admin/js/neon-chat.js"></script>
<script src="<?php echo e(asset('assets')); ?>/admin/js/neon-custom.js"></script>
<script src="<?php echo e(asset('assets')); ?>/admin/js/neon-demo.js"></script>