<?php $__env->startSection('title', 'Tambah Buku'); ?>
	
<?php $__env->startSection('contents'); ?>
	<ol class="breadcrumb bc-3">
		<li>
			<a href="index.html"><i class="entypo-home"></i>Home</a>
		</li>
		<li class="active">
			<strong>Tambah Member</strong>
		</li>
	</ol>	<div class="panel panel-primary" data-collapsed="0">
		
			<div class="panel-heading">
				<div class="panel-title">
					Tambah Member
				</div>
			</div>
			
			<div class="panel-body">
				
				<form action="<?php echo e(route('member_update', ['id'=>$member->id])); ?>" method="post" role="form" class="form-horizontal form-groups-bordered" enctype="multipart/form-data">
					<?php echo e(csrf_field()); ?>

					<input type="hidden" name="_method" value="PUT">
					
					<div class="form-group">
						<label for="field-1" class="col-sm-3 control-label">Nama</label>
						
						<div class="col-sm-5">
							<input type="text" name="name" value="<?php echo e($member->name); ?>" class="form-control">
						</div>
					</div>

					<div class="form-group">
						<label for="field-1" class="col-sm-3 control-label">Email</label>
						
						<div class="col-sm-5">
							<input type="text" name="email" value="<?php echo e($member->email); ?>" class="form-control">
						</div>
					</div>
					
					<div class="form-group">
						<label class="col-sm-3 control-label">Status</label>
						
						<div class="col-sm-5">
							<select name="id_role" class="form-control">
								<?php if($member->id_role == 1): ?>
									<option value="1" selected>Admin</option>
									<option value="2">Pimpinan</option>
									<option value="3">User</option>
								<?php elseif($member->id_role == 2): ?>
									<option value="1">Admin</option>
									<option value="2" selected>Pimpinan</option>
									<option value="3">User</option>
								<?php else: ?>
									<option value="1">Admin</option>
									<option value="2">Pimpinan</option>
									<option value="3" selected>User</option>
								<?php endif; ?>
							</select>
						</div>
					</div>

					<div class="form-group">
						<label for="field-1" class="col-sm-3 control-label">Password</label>
						
						<div class="col-sm-5">
							<input type="password" name="password" class="form-control">
						</div>
					</div>

					<div class="form-group">
						<label for="field-1" class="col-sm-3 control-label">Gambar</label>
						
						<div class="col-sm-5">
							<input type="file" name="image" class="form-control" id="field-file">
						</div>
					</div>
					
					
					<div class="form-group">
						<div class="col-sm-offset-3 col-sm-5">
							<button type="submit" class="btn btn-primary">Update</button>
						</div>
					</div>
				</form>
			</div>
		</div>
	<br />
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>