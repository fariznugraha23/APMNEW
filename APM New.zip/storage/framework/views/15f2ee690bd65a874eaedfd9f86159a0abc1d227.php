<?php $__env->startSection('title', 'List Buku'); ?>
	
<?php $__env->startSection('contents'); ?>
	<ol class="breadcrumb bc-3">
		<li>
			<a href="index.html"><i class="entypo-home"></i>Home</a>
		</li>
		<li class="active">
			<strong>List Member</strong>
		</li>
	</ol>
			
	<h2>List Member</h2>

	<br />
	<a href="<?php echo e(route('member_create')); ?>" class="btn btn-primary">Tambah Member</a>
	<br>
	<br>
	<table class="table table-bordered datatable" id="table-1">
		<thead>
			<tr>
				<th>No</th>
				<th>Nama</th>
				<th>Email</th>
				<th>Status</th>
				<th colspan="2">Action</th>
			</tr>
		</thead>
		<tbody>
			<?php 
				$no = 1;
			 ?>
			<?php $__currentLoopData = $member; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr class="odd gradeX">
					<td width="10px"><?php echo e($no++); ?></td>
					<td><?php echo e($m->name); ?></td>
					<td><?php echo e($m->email); ?></td>
					<td><?php echo e($m->role->nama_role); ?></td>
					<td width="20px">
						<a href="<?php echo e(route('member_edit', ['id' => $m->id])); ?>" class="btn btn-success">Edit</a>
					</td>
					<td width="20px">
						<form action="<?php echo e(route('member_delete')); ?>" method="post">
							<?php echo e(csrf_field()); ?>


							<input type="hidden" name="id" value="<?php echo e($m->id); ?>">
							<button type="submit" class="btn btn-danger">Hapus</button>
						</form>
					</td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>