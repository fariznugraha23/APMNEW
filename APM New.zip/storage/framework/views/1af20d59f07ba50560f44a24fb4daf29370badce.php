<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $__env->yieldContent('title', 'Admin'); ?></title>

	<?php echo $__env->make('admin.layouts.partial.meta', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	<?php echo $__env->yieldContent('styles'); ?>
</head>

<body class="page-body  page-fade" data-url="http://neon.dev">
	<div class="page-container">
		<!-- aside -->
		<?php echo $__env->make('admin.layouts.partial.aside', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<!-- / aside -->

		<!-- header -->
		<?php echo $__env->make('admin.layouts.partial.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<!-- / header -->
	</div>

	<hr />

	<div>
		<?php echo $__env->yieldContent('contents'); ?>
	</div>
	
	<!-- footer -->
	<?php echo $__env->make('admin.layouts.partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- / footer -->

	<!-- Javascript Libraries -->
	<?php echo $__env->make('admin.layouts.partial.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php echo $__env->yieldContent('modal'); ?>	
	<?php echo $__env->yieldContent('registerscript'); ?>	

</body>
</html>