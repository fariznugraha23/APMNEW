<?php $__env->startSection('title', 'Log Transaksi'); ?>
	
<?php $__env->startSection('contents'); ?>
	<ol class="breadcrumb bc-3">
		<li>
			<a href="#"><i class="entypo-home"></i>Home</a>
		</li>
		<li class="active">
			<strong>Log Transaksi</strong>
		</li>
	</ol>
			
	<h2>Log Transaksi</h2>

	<br />
	<a href="<?php echo e(route('transaksi_pdf')); ?>" class="btn btn-primary">Cetak</a>
	<br>
	<br>
	<div id="myDiv">
		<table class="table table-bordered datatable">
			<thead>
				<tr>
					<th>No</th>
					<th>Nama Peminjam</th>
					<th>Judul Buku</th>
					<th>Tanggal Pinjam</th>
					<th>Tanggal Kembali</th>
				</tr>
			</thead>
			<tbody>
				<?php $no = 1; ?>
				<?php $__currentLoopData = $transaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr class="odd gradeX">
						<td><?php echo e($no++); ?></td>
						<td><?php echo e($t->user->name); ?></td>
						<td><?php echo e($t->buku->judul); ?></td>
						<td><?php echo e($t->tgl_pinjam); ?></td>
						<td><?php echo e($t->tgl_kembali); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>