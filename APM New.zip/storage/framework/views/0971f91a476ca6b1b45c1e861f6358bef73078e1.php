<!DOCTYPE html>
<html lang="en">
<head>
	<title><?php echo $__env->yieldContent('title', 'Admin'); ?></title>

	<?php echo $__env->make('front.layouts.partial.meta', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	<?php echo $__env->yieldContent('styles'); ?>
</head>
<body>

	<div class="wrap">
		
		<!-- header -->
		<?php echo $__env->make('front.layouts.partial.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<!-- / header -->

		<?php echo $__env->yieldContent('contents'); ?>

		<!-- footer -->
		<?php echo $__env->make('front.layouts.partial.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		<!-- / footer -->

	</div>
	<!-- Javascript Libraries -->
	<?php echo $__env->make('front.layouts.partial.script', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php echo $__env->yieldContent('registerscript'); ?>
</body>
</html>