<?php $__env->startSection('title', 'Katalog Buku'); ?>
	
<?php $__env->startSection('contents'); ?>
	<section class="breadcrumb">
		<div class="container">
			<div class="row">
				<div class="col-sm-7">
					<h1>Area APM</h1>
					<ol class="breadcrumb bc-3">
						<li>
							<a href="<?php echo e(route('home')); ?>"><i class="entypo-home"></i>Home</a>
						</li>
						<li class="active">
							<strong>Area APM</strong>
						</li>
					</ol>			
				</div>
			</div>
		</div>
	</section>


	<!-- <section class="portfolio-container">
		<div class="container">
			<?php if(Auth::check()): ?>
				<?php
					$check = DB::table('transaksi')->where('id_user', Auth::user()->id)->where('tgl_kembali', 'Masih dipinjam')->count();
				 ?>
				<?php if($check == 5 ): ?> 
					<div class="alert alert-danger" role="alert">
						<button type="button" class="close" data-dismiss="alert">
							<span aria-hidden="true">&times;</span>
							<span class="sr-only">Close</span>
						</button>
						Anda telah meminjam buku melebihi batas yang telah ditentukan, untuk meminjam buku kembali anda harus mengembalikan buku yang telah dipinjam sebelumnya
					</div>
				<?php endif; ?>
			<?php endif; ?>
			<form action="<?php echo e(route('home_pencarian')); ?>" method="get">
				<?php echo e(csrf_field()); ?>

				<div class="col-md-10">
		 			<input type="text" name="keyword" class="form-control" placeholder="Cari buku...">
				</div>
				<div class="col-md-2">
					<button type="submit" class="btn btn-primary">Cari</button>
				</div>
			</form>

			
			<div class="row" id="portfolio-items">
				<?php $__empty_1 = true; $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
				<div class="item col-sm-4 col-xs-6 filter-design">
					<div class="portfolio-item">
						<a href="<?php echo e(route('home_detailbuku', ['id' => $b->id])); ?>" class="image">
							<img src="<?php echo e(asset('uploaded/buku')); ?>/<?php echo e($b->image); ?>" style="width: 300px; height: 350px" class="img-rounded" />
							<span class="hover-zoom"></span>
						</a>
						
						<h4>
							<a href="<?php echo e(route('home_detailbuku', ['id' => $b->id])); ?>" class="name"><?php echo e($b->judul); ?></a>
						</h4>
						
						<div class="categories">
							<a href="<?php echo e(route('home_jenis', ['jenis_buku' => $b->jenis])); ?>"><?php echo e($b->jenis); ?></a>
						</div>
					</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<p>Tidak ada buku yg terinput</p>
				<?php endif; ?>
			</div>
			
			<div class="row">
			
				<div class="col-md-12">
				
					<div class="text-center">
					
						<ul class="pagination">
							<?php echo e($buku->render()); ?>

						</ul>
						
					</div>
					
				</div>
				
			</div>
			
		</div>
		
	</section> -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>