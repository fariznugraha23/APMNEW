<!-- Footer -->
<footer class="main">
	&copy; 2018 <strong>Mashuri M</strong> Admin Theme by <a href="http://laborator.co" target="_blank">Laborator</a>
</footer>