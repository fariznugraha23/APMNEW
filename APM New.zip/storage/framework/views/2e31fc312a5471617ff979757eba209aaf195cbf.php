<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="Neon Admin Panel" />
<meta name="author" content="" />

<title>Neon | Frontend</title>


<link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/front/css/bootstrap.css">
<link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/front/css/font-icons/entypo/css/entypo.css">
<link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/front/css/neon.css">

<script src="<?php echo e(asset('assets')); ?>/front/js/jquery-1.11.0.min.js"></script>