<?php $__env->startSection('title', 'Dashboard'); ?>
	
<?php $__env->startSection('contents'); ?>
	<div class="row">
		<div class="col-sm-3">
			<div class="tile-stats tile-green">
				<div class="icon"><i class="entypo-thumbs-up"></i></div>
				<div class="num" data-start="0" data-end="<?php echo e($apms); ?>" data-postfix="" data-duration="1500" data-delay="0">0</div>
				
				<h3>Jumlah Nilai A</h3>
			</div>
			
		</div>
		<!-- <div class="col-sm-3">
			<div class="tile-stats tile-green">
				<div class="icon"><i class="entypo-thumbs-up"></i></div>
				<div class="num" data-start="0" data-end="<?php echo e($skor); ?>" data-postfix="" data-duration="1500" data-delay="0">0</div>
				
				<h3>Jumlah Skor</h3>
			</div>
			
		</div> -->
		<!-- <div class="col-sm-3">
			<div class="tile-stats tile-green">
				<div class="icon"><i class="entypo-thumbs-up"></i></div>
				<div class="num" data-start="0" data-end="" data-postfix="" data-duration="1500" data-delay="0">0</div>
				
				<h3>Jumlah Bobot</h3>
			</div>
			
		</div> -->

		<div class="col-sm-3">
		
			<div class="tile-stats tile-orange">
				<div class="icon"><i class="entypo-folder"></i></div>
				<div class="num" data-start="0" data-end="<?php echo e($jumlah_data); ?>" data-postfix="" data-duration="1500" data-delay="600">0</div>
				
				<h3>Jumlah Data</h3>
			</div>
			
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>